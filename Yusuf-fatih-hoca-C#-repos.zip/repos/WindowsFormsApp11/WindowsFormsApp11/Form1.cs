﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox1.Text, out int yil);
            DateTime dt1 = new DateTime();
            int haftasonugunu = 0;
            int enfazlaay = 0;
            for (int ay = 1; ay <= 12; ay++)

            {
                for (int gun = 1; gun <= DateTime.DaysInMonth(yil, ay); gun++)
                {
                    dt1 = new DateTime(yil, ay, gun);
                    if (dt1.DayOfWeek == DayOfWeek.Saturday || dt1.DayOfWeek == DayOfWeek.Sunday)
                    {
                        listBox1.Items.Add(dt1.ToShortDateString());
                        haftasonugunu++;


                    }
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
