﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cumle = textBox1.Text;
            string sonuc = "";

            for (int i = 0; i < cumle.Length; i++)
            {
                if (i == 0 || cumle[i - 1] == ' ')
                {
                    sonuc += char.ToUpper(cumle[i]);
                }
                else
                {
                    sonuc += cumle[i];
                }
            }

            textBox2.Text = sonuc;
        }
    }
    
}
