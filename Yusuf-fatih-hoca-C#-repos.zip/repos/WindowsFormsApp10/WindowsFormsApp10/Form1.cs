﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox3.Text, out int yil);
            DateTime baslangictarih2 = new DateTime(yil, 1, 1);
            int.TryParse(textBox4.Text, out int yil2);
            DateTime bitistarih2 = new DateTime(yil2, 1, 1);
            for(int i = 0; i < (yil - yil2).Days; i++)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox3.Text, out int yil);
            DateTime baslangictarih2 = new DateTime(yil, 1, 1);
            int.TryParse(textBox4.Text, out int yil2);
            DateTime bitistarih2 = new DateTime(yil2, 1, 1);
            Random rnd = new Random();
            int gunfarki = (bitistarih2 - baslangictarih2).Days;
            int rastgelegun = rnd.Next(gunfarki);
            DateTime rastlegetarih = baslangictarih2.AddDays(rastgelegun);
            listBox2.Items.Add(rastlegetarih.ToShortDateString());
            string gunadi = rastlegetarih.DayOfWeek.ToString();
            listBox3.Items.Add(gunadi);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
