﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            string[] kelimeler = textBox1.Text.Split(' ');

            for (int i = 0; i < kelimeler.Length - 1; i++)
            {
                for (int j = 0; j < kelimeler.Length - 1 - i; j++)
                {
                    if (kelimeler[j].Length > kelimeler[j + 1].Length)
                    {
                        string gecici = kelimeler[j];
                        kelimeler[j] = kelimeler[j + 1];
                        kelimeler[j + 1] = gecici;
                    }
                }
            }
            for (int i = 0; i < kelimeler.Length; i++)
            {
                listBox1.Items.Add(kelimeler[i]);
            }
        
        }
    }
}
