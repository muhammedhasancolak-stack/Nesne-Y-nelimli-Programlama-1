﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string tarih = " ";
            tarih = DateTime.Today.ToString();
            listBox1.Items.Add(tarih);
            tarih = DateTime.Now.ToString();
            listBox1.Items.Add(tarih);
            tarih = DateTime.Today.Year.ToString();
            listBox1.Items.Add(tarih);
            tarih = DateTime.Today.Day.ToString();
            listBox1.Items.Add(tarih);
            tarih = DateTime.Today.Hour.ToString();
            listBox1.Items.Add(tarih);
            tarih = DateTime.Today.AddDays(12).ToString();
            listBox1.Items.Add(tarih);
            DateTime dt = new DateTime();
            DateTime dt1 = new DateTime(1998, 2, 8);
            textBox1.Text = dateTimePicker1.Value.AddDays(12).ToString();
            //textbox1.Text = datetimePicker1.Value.AddDays(12).ToString();
            textBox1.Text = dateTimePicker1.Value.DayOfWeek.ToString();
            TimeSpan fark = dateTimePicker2.Value - dateTimePicker4.Value;
        }
    }
}
