﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = richTextBox1.Lines.Count().ToString();
            richTextBox1.SelectionBackColor = Color.Red;
            richTextBox1.SelectionColor = Color.Red;

            richTextBox1.AppendText("\n" + textBox1.Text);
            richTextBox1.Font = new Font("Consolas", 18f, FontStyle.Bold);
            textBox1.Text = richTextBox1.Find("fatih").ToString();
            textBox1.Text = richTextBox1.Size.Height.ToString();
            textBox1.Text = richTextBox1.Text;
            textBox1.Text = richTextBox1.SelectionLength.ToString();
            textBox1.Text = richTextBox1.SelectedText.Count().ToString();
            textBox1.Text = richTextBox1.SelectedText.Insert(3, "fatih");
            textBox1.Text = richTextBox1.SelectedText.IndexOf('a').ToString();
            textBox1.Text = richTextBox1.SelectedText.Replace('a', 'e');
            textBox1.Text = richTextBox1.SelectedText.Remove(4);
            textBox1.Text = richTextBox1.SelectedText.Remove(4, 3);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
