﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String cumle = "Marmara Üniversitesi Yapay Zeka Operatörlüğü";
            textBox1.Text = cumle;
            listBox1.Items.Add(cumle.Substring(4));
            listBox1.Items.Add(cumle.Substring(8, 12));
            listBox1.Items.Add(cumle.Trim());
            listBox1.Items.Add(cumle.TrimStart());
            listBox1.Items.Add(cumle.IndexOf("Ü"));
            listBox1.Items.Add(cumle.IndexOf("Üniversitesi"));
            listBox1.Items.Add(cumle.ToLower());
            listBox1.Items.Add(cumle.ToUpper());
            listBox1.Items.Add(cumle.Remove(5));
            listBox1.Items.Add(cumle.Remove(5, 4));
            listBox1.Items.Add(cumle.Replace('a', 'z'));
    
            listBox1.Items.Add(cumle.Insert(10, "Fatih"));
            listBox1.Items.Add(cumle.Length);
        }
    }
}
