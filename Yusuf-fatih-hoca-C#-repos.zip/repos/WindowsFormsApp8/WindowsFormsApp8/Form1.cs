﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TimeSpan gunfarki = DateTime.Today - dateTimePicker1.Value;
            int fark = gunfarki.Days;
            int yil = fark / 365;
            int gun = fark % 365;
            textBox1.Text = yil.ToString() + " yıl " + gun.ToString() + " gün";
        }
    }
}
